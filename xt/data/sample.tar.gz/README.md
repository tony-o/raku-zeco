# GREEN

[![Build Status](https://travis-ci.org/tony-o/perl6-green.svg)](https://travis-ci.org/tony-o/perl6-green)

[About Green](http://ugexe.com/parallel-testing-and-a-perilous-pilgrimage/)
